#total hours spent
#6/3: 3-8 -30 min exercise -30 min dinner 4hr
#6/4: study hall 1hr 4-8 -30min exercise - 30 min dinner 4hr
#6/5: no work
#6/6: 8hr - finished


import pygame
import sys
import math
import asyncio # for compilation to pygbag

pygame.init()

sw, sh = 1280, 720
fps = 60

cBg = (18, 14, 10)
cParchment = (210, 185, 140)
cDark = (40, 30, 18)
cGold = (200, 160, 50)
cRed = (160, 30, 20)
cGreen = (60, 130, 50)
cGrey = (100, 90, 80)
cWhite = (230, 220, 200)
cHighlight = (180, 140, 60)
cShadow = (8, 6, 4)
cStampRed = (140, 20, 20)
cStampGrn = (20, 100, 30)
cCream = (230, 215, 175)
cLocked = (30, 24, 14)

turns = ["Summer 1914", "Winter 1914", "Summer 1915", "Winter 1915", "Summer 1916", "Winter 1916", "Summer 1917", "Autumn 1918"]

turnPhases = {"Summer 1914": "DER AUFMARSCH", "Winter 1914": "DIE SCHÜTZENGRÄBEN", "Summer 1915": "STOCKENDER ANGRIFF", "Winter 1915": "VERSORGUNGSKRISE", "Summer 1916": "VERDUN UND DIE SOMME", "Winter 1916": "DAS HINDENBURG-PROGRAMM", "Summer 1917": "AMERICA TRITT EIN", "Autumn 1918": "DIE LETZTE ABRECHNUNG"}

resourcePoolBase = 200
resourceMin = 40
resourceMax = 305

UNLOCK_SCHEDULE = {0: {"gas", "artillery", "rail", "propaganda"}, 1: {"gas", "artillery", "rail", "propaganda"}, 2: {"gas", "artillery", "rail", "propaganda", "uboat", "medicine"}, 3: {"gas", "artillery", "rail", "propaganda", "uboat", "medicine"}, 4: {"gas", "artillery", "rail", "propaganda", "uboat", "medicine", "storm", "intelligence"}, 5: {"gas", "artillery", "rail", "propaganda", "uboat", "medicine", "storm", "intelligence"}, 6: {"gas", "artillery", "rail", "propaganda", "uboat", "medicine", "storm", "intelligence", "airforce", "armor"}, 7: {"gas", "artillery", "rail", "propaganda", "uboat", "medicine", "storm", "intelligence", "airforce", "armor"}}

def availableTechs(turnIndex): return UNLOCK_SCHEDULE.get(min(turnIndex, 7), set(techIds))

techs = [
    {"id": "gas", "name": "Poison Gas", "icon_color": (100, 180, 80), "desc": "Gas clouds on enemy positions.", "pros": ["Breaks enemy lines quickly", "Cheap to produce", "Demoralises the enemy"], "cons": ["Wind can blow it back on own men", "Enemy copies the methods", "Angers neutral countries"], "tiers": {0: "None", 30: "Field Trials", 80: "Ready for Use", 150: "Doctrine", 250: "Industrial Scale"}, "unlock_turn": 0},
    {"id": "artillery", "name": "Heavy Artillery", "icon_color": (160, 100, 60), "desc": "Larger guns, more shells.", "pros": ["Works in any weather", "Destroys any fortification", "Useful in any theatre"], "cons": ["Costs many resources", "Does not help men advance", "Very heavy to move"], "tiers": {0: "None", 30: "Battery", 80: "Corps Level", 150: "Army Level", 250: "Strategic"}, "unlock_turn": 0},
    {"id": "rail", "name": "Railways & Logistics", "icon_color": (120, 90, 60), "desc": "Rail lines for fast troop deployment.", "pros": ["Makes all other systems work better", "Fast reaction to weak points", "Keeps a long war going"], "cons": ["Does not harm the enemy directly", "Takes time to take effect", "Enemy aircraft hit the tracks"], "tiers": {0: "None", 30: "Patched Lines", 80: "Reliable Network", 150: "Optimised", 250: "Full Superiority"}, "unlock_turn": 0},
    {"id": "propaganda", "name": "Propaganda", "icon_color": (180, 140, 80), "desc": "Control news, sustain the home front.", "pros": ["Keeps the home front quiet", "Prevents soldiers' hopelessness", "Influences neutral countries"], "cons": ["Does not help on the battlefield", "Collapses with too much bad news", "Very expensive long term"], "tiers": {0: "None", 30: "Leaflets", 80: "Press Control", 150: "Full Narrative", 250: "Information Warfare"}, "unlock_turn": 0},
    {"id": "uboat", "name": "U-Boat Fleet", "icon_color": (50, 90, 160), "desc": "U-boats cut British supply lines.", "pros": ["Stops enemy food and weapons", "High damage for the cost", "Severely harms British economy"], "cons": ["America might enter the war against us", "Experienced crews hard to replace", "Upsets countries not in the war"], "tiers": {0: "None", 30: "Coastal Patrols", 80: "Atlantic Operations", 150: "Unrestricted", 250: "Total Blockade"}, "unlock_turn": 2},
    {"id": "medicine", "name": "Field Medicine", "icon_color": (200, 200, 200), "desc": "Improve field hospitals, stop epidemics.", "pros": ["Brings wounded soldiers back faster", "Reduces deaths from disease", "Gives soldiers a sense of safety"], "cons": ["Takes money away from weapons", "Results barely visible daily", "Requires trained personnel"], "tiers": {0: "None", 30: "Medical Posts", 80: "Field Hospitals", 150: "Surgical Corps", 250: "Modern Medicine"}, "unlock_turn": 2},
    {"id": "storm", "name": "Stormtroopers", "icon_color": (180, 60, 40), "desc": "Small fast groups pierce enemy lines.", "pros": ["Directly breaks trench warfare stalemates", "Boosts morale of regular soldiers", "Works well with artillery"], "cons": ["Training takes time and money", "Need support or they die", "Heavy losses without backing"], "tiers": {0: "None", 30: "Test Units", 80: "Storm Squads", 150: "Full Divisions", 250: "Elite Wedge"}, "unlock_turn": 4},
    {"id": "intelligence", "name": "Intelligence Service", "icon_color": (160, 80, 160), "desc": "Spy networks and decoding enemy messages.", "pros": ["Knowledge of enemy plans saves lives", "Sabotage disrupts enemy supply", "Helps in peace talks"], "cons": ["Results barely directly visible", "Caught spies cause great damage", "Expensive and unreliable"], "tiers": {0: "None", 30: "Field Agents", 80: "Intelligence Office", 150: "Full Network", 250: "Total Coverage"}, "unlock_turn": 4},
    {"id": "airforce", "name": "Air Forces", "icon_color": (140, 160, 200), "desc": "Fighter planes and reconnaissance aircraft.", "pros": ["Sees every enemy move from above", "Attacks supply lines behind the lines", "Wins support at home"], "cons": ["Planes are expensive to build and replace", "Good pilots are rare", "Enemy factories catch up quickly"], "tiers": {0: "None", 30: "Reconnaissance Flights", 80: "Air Superiority", 150: "Strategic Bombing", 250: "Air Dominance"}, "unlock_turn": 6},
    {"id": "armor", "name": "Armoured Vehicles", "icon_color": (80, 100, 60), "desc": "Build early tanks and armoured cars.", "pros": ["Destroys barbed wire and machine gun nests", "Protects infantry from bullets", "Shocks and terrifies the enemy"], "cons": ["Breaks down often at this early stage", "Drinks too much fuel", "Factories can build only few"], "tiers": {0: "None", 30: "Prototypes", 80: "Company Strength", 150: "Battalion Strength", 250: "Full Doctrine"}, "unlock_turn": 6}
]

techIds = [t["id"] for t in techs]
techById = {t["id"]: t for t in techs}

def tierLabel(invDict, tid): pts = invDict.get(tid, 0); tech = techById[tid]; Tiers = sorted(tech["tiers"].items()); result = Tiers[0][1]; ([(result := label) for threshold, label in Tiers if pts >= threshold]); return result
def scoreDeltaScaled(baseDelta, invDict, tid, threshold): 
    if (invDict is None): return baseDelta; pts = invDict.get(tid, 0);  scale = max(0.5, min(2.0, pts / threshold)) if threshold else 1.0; return int(round(baseDelta * scale))
def _inv(inv, tid, t): return inv.get(tid, 0) >= t

events = [
    {"bucket": 0, "condition": lambda inv, ws, fl: _inv(inv, "gas", 20), "headline": "ERSTER GASANGRIFF", "english": "First Gas Attack", "body": "Gas canisters are opened along the front. A yellow-green cloud rolls into enemy trenches. Thousands of men fall in minutes. Berlin ignores the angry letters from abroad. The line has moved three kilometers, a miracle", "delta": 5, "scale_tech": "gas", "scale_threshold": 20, "flag": "gas_used_early"},
    {"bucket": 0, "condition": lambda inv, ws, fl: _inv(inv, "artillery", 30), "headline": "KRUPP LIEFERT", "english": "Krupp (weapons builder) Delivers", "body": "The new heavy guns break the concrete fortifications in two days. Enemy officers surrender stunned. Army leaders across Europe take notice. Germany has shown what it can do.", "delta": 4, "scale_tech": "artillery", "scale_threshold": 30, "flag": "arty-boy"},
    {"bucket": 0, "condition": lambda inv, ws, fl: _inv(inv, "rail", 25), "headline": "EISENBAHNVORSPRUNG", "english": "Rail Advantage", "body": "Our trains deploy three full army groups to the front in six days. The enemy marches on foot and arrives late every time. This advantage will not last. The enemy is already building more tracks.", "delta": 3, "scale_tech": "rail", "scale_threshold": 25, "flag": "railed"},
    {"bucket": 0, "condition": lambda inv, ws, fl: _inv(inv, "propaganda", 20), "headline": "HEIMATFRONT MOBILISIERT", "english": "Home Front Mobilised", "body": "Newspapers report on the glorious advance. Factories report for night shifts. The mood is good, but the leadership knows: Without good news, this cannot last forever.", "delta": 2, "scale_tech": "propaganda", "scale_threshold": 20, "flag": "spreadLies"},
    {"bucket": 0, "condition": lambda inv, ws, fl: not any(_inv(inv, t, 20) for t in ["gas", "artillery", "rail", "propaganda"]), "headline": "DER GENERALSTAB IST BESORGT", "english": "The General Staff Is Worried", "body": "The first month has passed and no programme has made progress. A general writes: We are fighting with the means of 1870. The enemy is already building new weapons. This inertia will cost us dearly.", "delta": -6, "flag": "nothing"},
    {"bucket": 1, "condition": lambda inv, ws, fl: _inv(inv, "uboat", 30), "headline": "DIE LUSITANIA VERSENKT", "english": "Lusitania Sunk", "body": "A U-boat sinks a large passenger liner near Ireland. It goes down in eighteen minutes. Over a thousand people die, including many Americans. The American president sends three angry letters. Washington is no longer neutral — they are on the verge of entering the war.", "delta": -5, "scale_tech": "uboat", "scale_threshold": 30, "flag": "lusitania"},
    {"bucket": 1, "condition": lambda inv, ws, fl: _inv(inv, "artillery", 25) and "arty-boy" in fl, "headline": "FOKKER-GEISSEL", "english": "The Fokker Scourge", "body": "Mass losses in the trenches Men going to no man's land are blown to pieces The enemy soldiers fear going over.", "delta": 4, "scale_tech": "artillery", "scale_threshold": 25, "flag": "hif35"},
    {"bucket": 1, "condition": lambda inv, ws, fl: _inv(inv, "gas", 40) and _inv(inv, "artillery", 25), "headline": "VERBUNDENE WAFFEN WIRKEN", "english": "Combined Arms Work", "body": "Heavy guns force the enemy into their holes. Then gas rolls in. One weapon can be survived. Both together cannot. Three enemy groups are wiped out before noon.", "delta": 7, "scale_tech": "gas", "scale_threshold": 40, "flag": "gas_arty_combo"},
    {"bucket": 1, "condition": lambda inv, ws, fl: _inv(inv, "propaganda", 25), "headline": "DIE HEIMATFRONT HÄLT", "english": "The Home Front Holds", "body": "The people back home are spending more money on the war. The mood is still strong. But the leadership knows: Without good news, this cannot last forever.", "delta": 3, "scale_tech": "propaganda", "scale_threshold": 25, "flag": "goodProp"},
    {"bucket": 1, "condition": lambda inv, ws, fl: _inv(inv, "medicine", 25), "headline": "DIE VERWUNDETEN KEHREN ZURÜCK", "english": "The Wounded Return", "body": "Better field hospitals shorten the time between injury and treatment. Forty thousand men return within six weeks. A general writes: I lost my regiment at the front and got it back from the hospital.", "delta": 3, "scale_tech": "medicine", "scale_threshold": 25, "flag": "healUpGoys"},
    {"bucket": 1, "condition": lambda inv, ws, fl: ws <= 42, "headline": "STELLUNGSKRIEG BEGINNT", "english": "The War of Attrition Begins", "body": "The war of movement is over. Both sides dig in. Hundreds of kilometres of trenches stretch through Belgium and France. What was planned as a six-week campaign becomes a multi-year war.", "delta": -5, "flag": "trench_war"},
    {"bucket": 2, "condition": lambda inv, ws, fl: _inv(inv, "uboat", 60) and "lusitania" in fl, "headline": "WASHINGTON ERTEILT LETZTES ULTIMATUM", "english": "Washington Issues Final Warning", "body": "More ships have been sunk. The American president speaks before his Congress. His letter to Berlin is a final warning in clear language. Our man in Washington cables back: America is ready to fight. The admirals say he is wrong. He is not wrong.", "delta": -9, "scale_tech": "uboat", "scale_threshold": 60, "flag": "usa_warning"},
    {"bucket": 2, "condition": lambda inv, ws, fl: _inv(inv, "gas", 50) and "gas_used_early" in fl, "headline": "GASMASKEN ÜBERALL", "english": "The Enemy Has Gas Masks Now", "body": "Every enemy soldier now wears a functional mask. Gas is no longer feared, it is simply handled. Our best breakthrough weapon has been copied and neutralised. We need a new way.", "delta": -6, "scale_tech": "gas", "scale_threshold": 50, "flag": "gas_countered"},
    {"bucket": 2, "condition": lambda inv, ws, fl: _inv(inv, "rail", 40) and _inv(inv, "artillery", 30), "headline": "VERSORGUNGSNETZ GEFESTIGT", "english": "Supply Network Consolidated", "body": "New tracks connect munitions works directly with the front. Shell deliveries double within a month. The enemy still lacks artillery for a serious response.", "delta": 5, "scale_tech": "rail", "scale_threshold": 40, "flag": "rail_supply"},
    {"bucket": 2, "condition": lambda inv, ws, fl: _inv(inv, "intelligence", 50), "headline": "RAUM 40 ENTTARNT", "english": "Room 40 Exposed", "body": "Our spy team discovers that the British navy is reading our coded messages. New codes are sent to every ship. The British are blind for three months. The next major naval battle will be fought during this time.", "delta": 5, "scale_tech": "intelligence", "scale_threshold": 50, "flag": "signals_intel"},
    {"bucket": 2, "condition": lambda inv, ws, fl: not any(_inv(inv, t, 40) for t in techIds), "headline": "NICHTS GELERNT", "english": "Nothing Mastered", "body": "The annual report is three pages long and says almost nothing. Every programme received a little money. None received enough to have an effect. The front has not moved a kilometre in twelve months. A margin note reads: We are losing because we tried to do everything at once.", "delta": -10, "flag": "overextended_1915"},
    {"bucket": 2, "condition": lambda inv, ws, fl: ws <= 36, "headline": "VERSORGUNGSENGPASS", "english": "Supply Shortage", "body": "The munitions works cannot keep up. Shells are rationed. Soldates report that they sometimes have only three shots per day. The British blockade is having an effect.", "delta": -7, "flag": "supply_crisis"},
    {"bucket": 3, "condition": lambda inv, ws, fl: "usa_warning" in fl and _inv(inv, "uboat", 80), "headline": "AMERICA TRITT IN DEN KRIEG EIN", "english": "America Enters the War", "body": "The American president declares to his nation: They must fight. Our ambassador is expelled this very evening. Two million American soldiers will arrive within the year. They are well-fed and have not spent three winters in the mud. Our last chance was to win before they arrived. That chance is gone.", "delta": -20, "scale_tech": "uboat", "scale_threshold": 80, "flag": "usa_enters"},
    {"bucket": 3, "condition": lambda inv, ws, fl: _inv(inv, "propaganda", 55), "headline": "MEUTEREI ABGEWEHRT", "english": "Mutiny Prevented", "body": "The enemy army has large groups of soldiers refusing orders after a failed attack. On our side, it is different. Letters from the front are read before forwarding. Bad news is slowed down. The army remains in the field.", "delta": 6, "scale_tech": "propaganda", "scale_threshold": 55, "flag": "mutiny_prevented"},
    {"bucket": 3, "condition": lambda inv, ws, fl: _inv(inv, "medicine", 50) and _inv(inv, "rail", 35), "headline": "LAZARETTZÜGE RETTEN LEBEN", "english": "Hospital Trains Save Lives", "body": "Special trains transport wounded out of the trench area in less than four hours. The survival rate for abdominal injuries rises by thirty percent. The enemy still has wounded lying in no man's land for days.", "delta": 5, "scale_tech": "medicine", "scale_threshold": 50, "flag": "hospital_trains"},
    {"bucket": 3, "condition": lambda inv, ws, fl: not any(_inv(inv, t, 50) for t in techIds), "headline": "GENERALSTAB ZWEIFELT", "english": "High Command Doubts", "body": "The Chief of the General Staff places his report on the table. Three years, no decisive breakthrough, no dominating weapon. He writes in the final line: If we continue like this, we will not lose because of the enemy. We will lose because of ourselves.", "delta": -11, "flag": "highcommand_doubt"},
    {"bucket": 3, "condition": lambda inv, ws, fl: ws <= 34, "headline": "HUNGER IN DEN STÄDTEN", "english": "Hunger in the Cities", "body": "The blockade pushes through. Bread stamps are introduced. Women stand for hours in queues before empty shelves. Every defeat at the front makes the mood at home even worse.", "delta": -7, "flag": "city_hunger"},
    {"bucket": 4, "condition": lambda inv, ws, fl: _inv(inv, "artillery", 70) and _inv(inv, "rail", 55), "headline": "DIE FRÜHJAHRSOFFENSIVE", "english": "The Spring Offensive", "body": "The attack begins in the early morning mist. Thousands of guns fire for five hours. Then our troops advance thirty kilometres in a single day. The enemy commander orders his men to fight to the last. For a week, it looks like we could win the entire war.", "delta": 10, "scale_tech": "artillery", "scale_threshold": 70, "flag": "spring_offensive"},
    {"bucket": 4, "condition": lambda inv, ws, fl: _inv(inv, "propaganda", 70) and "mutiny_prevented" in fl, "headline": "DER SIEG IST NAH", "english": "Victory Is Close", "body": "With the attack grinding to a halt, the news machine changes its message. Peace is coming soon. The people back home believe it because they need to. The army holds together for another season because of it.", "delta": 5, "scale_tech": "propaganda", "scale_threshold": 70, "flag": "late_propaganda"},
    {"bucket": 4, "condition": lambda inv, ws, fl: "usa_enters" in fl, "headline": "DIE AMERIKANISCHE FLUT", "english": "The American Tide", "body": "American soldiers arrive by the thousands every single day. They have not been gassed. They have not spent years in the cold mud. On our side, the numbers go only in one direction.", "delta": -14, "flag": "american_tide"},
    {"bucket": 4, "condition": lambda inv, ws, fl: _inv(inv, "medicine", 70) and _inv(inv, "propaganda", 45), "headline": "DIE INFLUENZA TRIFFT", "english": "Influenza Strikes", "body": "A severe illness spreads at the front. Our men are already weakened by food shortages. Our medical teams handle it better than the enemy. Fifty thousand dead is terrible — but it could have been far worse.", "delta": 3, "scale_tech": "medicine", "scale_threshold": 70, "flag": "flu_managed"},
    {"bucket": 4, "condition": lambda inv, ws, fl: ws <= 32, "headline": "VERDUN-BLUTSAUGER", "english": "The Verdun Meatgrinder", "body": "The fighting around Verdun claims casualties that no general staff could predict. Three hundred thousand men in four months. Every captured ruin is retaken four times. The army is still fighting, but it is no longer the same.", "delta": -9, "flag": "verdun_loss"},
    {"bucket": 5, "condition": lambda inv, ws, fl: _inv(inv, "rail", 60) and _inv(inv, "storm", 55), "headline": "SCHNELLE VERLEGUNG", "english": "Fast Redeployment", "body": "Railway lines move entire divisions overnight from calm fronts to the attack point. Enemy commanders expected forty-eight hours warning. They receive none. Our troops are in the enemy's reserve trenches at dawn.", "delta": 7, "scale_tech": "rail", "scale_threshold": 60, "flag": "rail_storm_combo"},
    {"bucket": 5, "condition": lambda inv, ws, fl: _inv(inv, "intelligence", 60) and _inv(inv, "propaganda", 50), "headline": "DOPPELSPIEL AM KAISERHOF", "english": "Double Game at the Imperial Court", "body": "An enemy agent is caught in Berlin. With him: a complete index of British contacts. Thirty names. The interrogations reveal the attack plan for the next season. For once, we know what the enemy is thinking.", "delta": 6, "scale_tech": "intelligence", "scale_threshold": 60, "flag": "double_agent"},
    {"bucket": 5, "condition": lambda inv, ws, fl: ws <= 30, "headline": "DIE ARMEE BRICHT", "english": "The Army Is Breaking", "body": "Reports reach Berlin: Soldiers are abandoning the front on their own authority. Not many yet, not now. But the number grows every week. The army that held for four years is beginning to fall apart. Time is running out.", "delta": -10, "flag": "morale_collapse"},
    {"bucket": 5, "condition": lambda inv, ws, fl: not any(_inv(inv, t, 60) for t in techIds), "headline": "DAS HINDENBURG-PROGRAMM SCHEITERT", "english": "The Hindenburg Programme Fails", "body": "The armaments programme was supposed to double production. Instead, the essentials are missing everywhere. Nobody decided what had priority. The result is mediocrity everywhere and strength nowhere.", "delta": -9, "flag": "hindenburg_fail"},
    {"bucket": 6, "condition": lambda inv, ws, fl: _inv(inv, "airforce", 80) and _inv(inv, "artillery", 55), "headline": "LUFT UND GESCHÜTZE", "english": "Aircraft Guide the Shells", "body": "Our aircraft spot targets and radio the exact position to our batteries. Shells land on headquarters and supply depots that were previously hidden from us. The enemy command is disrupted for days. This is a new way to fight — and we are ahead.", "delta": 8, "scale_tech": "airforce", "scale_threshold": 80, "flag": "air_arty_combo"},
    {"bucket": 6, "condition": lambda inv, ws, fl: _inv(inv, "armor", 70) and _inv(inv, "storm", 60), "headline": "PANZERSTURM", "english": "Armoured Stormtroopers", "body": "Tanks break through the barbed wire and knock out machine gun nests. Fast soldiers pour through the gaps. The enemy line collapses in six hours. Thousands are taken prisoner. Our commander writes: Now I see what a modern army can really do.", "delta": 11, "scale_tech": "armor", "scale_threshold": 70, "flag": "tank_storm_combo"},
    {"bucket": 6, "condition": lambda inv, ws, fl: ws <= 28, "headline": "REVOLUTION IN DEN HEIMATSTÄDTEN", "english": "Revolution at Home", "body": "Factories in Berlin and Hamburg stand still. Workers march through the streets. The government can no longer cover it up. The army is losing the war and the people back home know it now.", "delta": -12, "flag": "home_revolution"},
    {"bucket": 6, "condition": lambda inv, ws, fl: "usa_enters" in fl and ws < 45, "headline": "AMERIKANISCHE DIVISIONEN IM EINSATZ", "english": "American Divisions in Action", "body": "The fresh troops from America are now in the field. Our men have held out for four years. These men are rested, well-equipped and full of confidence. The enemy has an inexhaustible reserve. We have none.", "delta": -10, "flag": "americans_fighting"},
    {"bucket": 7, "condition": lambda inv, ws, fl: ws >= 70, "headline": "WAFFENSTILLSTAND AUS STÄRKE", "english": "Peace from Strength", "body": "We come to the table without shame. The conditions are harsh but survivable. There is no war guilt clause. The delegation returns home. No riots await them.", "delta": 8, "flag": "good_armistice"},
    {"bucket": 7, "condition": lambda inv, ws, fl: ws < 70 and ws >= 45, "headline": "UNENTSCHIEDENER WAFFENSTILLSTAND", "english": "An Undecided Armistice", "body": "Neither victory nor defeat. We keep our borders but must cede colonies and pay heavy reparations. Soldiers return home to an exhausted country. The Republic has a chance. It is small.", "delta": -3, "flag": "neutral_armistice"},
    {"bucket": 7, "condition": lambda inv, ws, fl: ws < 45, "headline": "KAPITULATION", "english": "We Sign in Defeat", "body": "The army collapses faster than anyone had expected. The peace papers are signed in an enemy railway carriage in a French forest. These conditions are no peace. They are a twenty-year pause. The new country is born with something it cannot shake off.", "delta": -12, "flag": "bad_armistice"},
    {"bucket": 2, "condition": lambda inv, ws, fl: inv.get("gas", 0) > 240, "headline": "ZU VIEL GAS, ZU WENIG ANDERES", "english": "Too Much Gas, Too Little Else", "body": "We have more gas than we can ever use. But men are still dying in the trenches because we have no other answer. Commanders beg for more shells. There are none.", "delta": -8, "flag": "gas_overinvest"},
    {"bucket": 3, "condition": lambda inv, ws, fl: inv.get("uboat", 0) > 240 and "usa_enters" not in fl, "headline": "U-BOOTE ÜBERALL, KRIEG NIRGENDWO", "english": "U-Boats Everywhere, War Nowhere", "body": "We have built U-boats faster than we can man them. Half of the fleet lies in port without trained men. The money would have been better spent on the land war. America is still watching — and their patience is thin.", "delta": -7, "flag": "uboat_overinvest"},
    {"bucket": 4, "condition": lambda inv, ws, fl: inv.get("propaganda", 0) > 240, "headline": "NIEMAND GLAUBT ES MEHR", "english": "Nobody Believes It Anymore", "body": "We have said victory is close for so long that nobody believes it anymore. Letters from the front describe something completely different from what the newspapers say. The propaganda machine keeps running, but the fuel is spent. The people back home are angry and tired.", "delta": -9, "flag": "propaganda_overinvest"},
    {"bucket": 5, "condition": lambda inv, ws, fl: inv.get("artillery", 0) > 240 and not _inv(inv, "storm", 40), "headline": "GRANATEN OHNE INFANTERIE", "english": "Shells Without Infantry", "body": "We have more shells than the enemy can expend in a year. But after each bombardment, there are no stormtroopers to exploit the breakthrough. The enemy line recovers every time. We paid for steel instead of soldiers.", "delta": -8, "flag": "artillery_no_infantry"},
    {"bucket": 6, "condition": lambda inv, ws, fl: ws <= 25, "headline": "DAS HEER IST AM ENDE", "english": "The Army Is Finished", "body": "Divisions report strengths of thirty percent. Artillerymen have shells for two days. The staff officers are no longer discussing attack plans. They are discussing lines of retreat.", "delta": -13, "flag": "army_collapsed"}
]

outcomes = {
    "victory": {"title": "HINDENBURG PEACE", "english": "Peace on German Terms", "subtitle": "Germany sits at the table as an equal — November 1918", "body": "The enemy attacks exhaust themselves. Allied supplies are running low. Great Britain asks for terms. We do not dictate. But we are not on our knees either. The new government begins from a position of strength, not shame. Your decisions made the difference.", "color": cGold, "stamp": "GENEHMIGT", "stamp_english": "APPROVED"},
    "stalemate": {"title": "ARMISTICE", "english": "Armistice", "subtitle": "The guns fall silent — 11 November 1918", "body": "Neither side is broken. Neither side has won. We keep our borders but cede colonies and must pay heavy reparations. Soldiers return home to a tired country. The Republic has a chance. It is small. What comes next has not yet been decided.", "color": cGrey, "stamp": "UNENTSCHIEDEN", "stamp_english": "UNDECIDED"},
    "defeat": {"title": "SURRENDER", "english": "Defeat", "subtitle": "The Kaiser leaves Berlin — 9 November 1918", "body": "Revolution in Berlin. The navy refuses to sail out. The army collapses faster than anyone thought. The peace terms lay all blame solely upon us. The debts we must pay are intended to humiliate. The new country is born out of loss and will bear this weight for a long time. Your decisions led here.", "color": cRed, "stamp": "ABGELEHNT", "stamp_english": "REJECTED"}
}
def pixelFont(size):
    try:
        return pygame.font.Font(None, size)
    except:
        return pygame.font.SysFont("monospace", size)


fontTiny = pixelFont(16)
fontSm = pixelFont(22)
fontMd = pixelFont(30)
fontLg = pixelFont(42)
fontXl = pixelFont(64)
fontTitle = pixelFont(88)
fontStamp = pixelFont(72)


def drawText(surf, text, font, color, x, y, shadow=True, center=False):
    rendered = font.render(text, False, color)
    if center:
        x -= rendered.get_width() // 2
    if shadow:
        sh = font.render(text, False, cShadow)
        surf.blit(sh, (x + 2, y + 2))
    surf.blit(rendered, (x, y))
    return rendered.get_width()


def drawTextWrapped(surf, text, font, color, rect, lineSpacing=6):
    words = text.split()
    lines, current = [], ""
    for word in words:
        test = (current + " " + word).strip()
        if font.size(test)[0] <= rect.width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    y = rect.y
    for line in lines:
        if y + font.get_height() > rect.bottom:
            break
        drawText(surf, line, font, color, rect.x, y, shadow=False)
        y += font.get_height() + lineSpacing
    return y


def wrapText(text, font, maxWidth):
    words = text.split()
    lines, current = [], ""
    for word in words:
        test = (current + " " + word).strip()
        if font.size(test)[0] <= maxWidth:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def drawTextWrappedPartial(
    surf, text, font, color, rect, lineSpacing=6, charsVisible=None
):
    lines = wrapText(text, font, rect.width)
    y, shown = rect.y, 0
    for line in lines:
        if y + font.get_height() > rect.bottom:
            break
        if charsVisible is None:
            drawText(surf, line, font, color, rect.x, y, shadow=False)
            shown += len(line)
        else:
            remaining = charsVisible - shown
            if remaining <= 0:
                break
            partial = line[:remaining]
            drawText(surf, partial, font, color, rect.x, y, shadow=False)
            shown += len(line)
        y += font.get_height() + lineSpacing
    return shown


def drawRectBorder(surf, rect, color, thickness=2, inner=None):
    if inner is None:
        inner = cShadow
    pygame.draw.rect(surf, inner, rect)
    pygame.draw.rect(surf, color, rect, thickness)


def lerpColor(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def drawStamp(surf, text, cx, cy, color, angleDeg=-12, font=None):
    f = font or fontStamp
    raw = f.render(text, False, color)
    out = pygame.Surface(raw.get_size(), pygame.SRCALPHA)
    out.blit(raw, (0, 0))
    rot = pygame.transform.rotate(out, angleDeg)
    faded = pygame.Surface(rot.get_size(), pygame.SRCALPHA)
    faded.fill((*color, 180))
    mask = pygame.Surface(rot.get_size(), pygame.SRCALPHA)
    mask.blit(rot, (0, 0))
    mask.blit(faded, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surf.blit(mask, (cx - mask.get_width() // 2, cy - mask.get_height() // 2))
    print(f"stamped {text} at {cx},{cy}")

def drawTechIcon(surf, techId, cx, cy, size=40, color=None):
    c = color or techById[techId]["icon_color"]
    dark = tuple(max(0, v - 60) for v in c)
    s = size
    if techId == "gas":
        for dx, dy, rad in [
            (-8, 0, 7),
            (8, 0, 7),
            (0, -6, 6),
            (0, 6, 5),
            (-4, 8, 5),
            (4, 8, 5),
        ]:
            pygame.draw.circle(surf, c, (cx + dx, cy + dy), rad)
        pygame.draw.circle(surf, dark, (cx, cy), 5)
    elif techId == "artillery":
        pygame.draw.rect(surf, c, (cx - s // 2 + 4, cy - 6, s - 8, 12))
        pygame.draw.circle(surf, dark, (cx + s // 2 - 8, cy), 8)
        pygame.draw.rect(surf, dark, (cx - s // 2 + 4, cy - 8, 12, 16))
    elif techId == "uboat":
        pygame.draw.ellipse(surf, c, (cx - s // 2 + 2, cy - 8, s - 4, 16))
        pygame.draw.rect(surf, dark, (cx - 4, cy - 16, 8, 10))
        pygame.draw.rect(surf, c, (cx - 3, cy - 15, 6, 8))
    elif techId == "storm":
        pygame.draw.ellipse(surf, c, (cx - 12, cy - 10, 24, 14))
        pygame.draw.rect(surf, c, (cx - 10, cy + 2, 20, 8))
        pygame.draw.rect(surf, dark, (cx - 6, cy + 6, 12, 12))
    elif techId == "airforce":
        pygame.draw.rect(surf, c, (cx - s // 2 + 2, cy - 4, s - 4, 8))
        pygame.draw.rect(surf, dark, (cx - s // 2 + 8, cy - 12, s - 16, 6))
        pygame.draw.ellipse(surf, dark, (cx + s // 2 - 14, cy - 4, 10, 8))
    elif techId == "rail":
        pygame.draw.rect(surf, c, (cx - s // 2 + 4, cy - 3, s - 8, 6))
        for x in range(cx - s // 2 + 4, cx + s // 2 - 8, 10):
            pygame.draw.rect(surf, dark, (x, cy - 8, 5, 16))
    elif techId == "armor":
        pygame.draw.rect(surf, c, (cx - s // 2 + 4, cy - 8, s - 8, 16))
        pygame.draw.rect(surf, dark, (cx - s // 2 + 2, cy - 12, s - 4, 8))
        pygame.draw.rect(surf, c, (cx - s // 2 + 2, cy + 6, s - 4, 8))
        pygame.draw.rect(surf, dark, (cx, cy - 14, 20, 5))
    elif techId == "propaganda":
        pygame.draw.polygon(
            surf,
            c,
            [
                (cx - 14, cy - 6),
                (cx - 14, cy + 6),
                (cx + 14, cy + 14),
                (cx + 14, cy - 14),
            ],
        )
        pygame.draw.rect(surf, dark, (cx + 14, cy - 8, 6, 16))
    elif techId == "medicine":
        pygame.draw.rect(surf, c, (cx - 4, cy - s // 2 + 4, 8, s - 8))
        pygame.draw.rect(surf, c, (cx - s // 2 + 4, cy - 4, s - 8, 8))
    elif techId == "intelligence":
        pygame.draw.circle(surf, c, (cx, cy), s // 2 - 4, 3)
        pygame.draw.circle(surf, dark, (cx, cy), 4)
        pygame.draw.line(surf, c, (cx, cy - s // 2 + 4), (cx, cy - 8), 2)

class GameState:
    def __init__(self): self.reset()

    def reset(self):
        self.warScore = 40
        self.turnIndex = 0
        self.phase = "menu"
        self.investments = {t: 0 for t in techIds}
        self.yearAlloc = {t: 0 for t in techIds}
        self.flags = set()
        self.eventQueue = []
        self.history = []
        self.pointsLeft = resourcePoolBase
        self.reviewMode = False
        self.earlyEnd = False
        print("reset gamestate")

    @property
    def currentTurn(self): return turns[min(self.turnIndex, len(turns) - 1)]

    @property
    def currentPhase(self): return turnPhases.get(self.currentTurn, "")

    @property
    def currentBucket(self): return min(self.turnIndex, 7)

    def dynamicResourcePool(self):
        t = self.warScore / 100.0
        return int(resourceMin + t * (resourceMax - resourceMin))

    def startTurn(self):
        self.yearAlloc = {t: 0 for t in techIds}
        self.pointsLeft = self.dynamicResourcePool()
        self.reviewMode = False

    def commitYear(self):
        for tid in techIds: self.investments[tid] += self.yearAlloc[tid]

        fired = []
        bucket = self.currentBucket
        for ev in events:
            flag = ev.get("flag")
            if ev["bucket"] != bucket: continue
            if flag and flag in self.flags: continue
            if ev["condition"](self.investments, self.warScore, self.flags):
                base = ev.get("delta", 0)
                st = ev.get("scale_tech")
                thresh = ev.get("scale_threshold", 1)
                delta = scoreDeltaScaled(base, self.investments, st, thresh) if st else base
                self.warScore = max(0, min(100, self.warScore + delta))
                evCopy = dict(ev)
                evCopy["actual_delta"] = delta
                fired.append(evCopy)
                if flag: self.flags.add(flag)

        self.history.append((self.currentTurn, dict(self.yearAlloc), fired))
        self.eventQueue = fired
        self.turnIndex += 1

        if self.warScore <= 8:
            self.earlyEnd = True
            return "outcome"

        if self.turnIndex >= len(turns): return "outcome"

        self.startTurn()
        return "event"

    def result(self):
        if self.warScore >= 70: return "victory"
        if self.warScore <= 35: return "defeat"
        return "stalemate"


class Screen:
    def __init__(self, gs, surf):
        self.gs = gs
        self.surf = surf
        self.tick = 0

    def handle(self, event): return None

    def update(self): self.tick += 1

    def draw(self): pass


class MenuScreen(Screen):
    def __init__(self, gs, surf):
        super().__init__(gs, surf)
        self.buttons = [
            {"label": "START CAMPAIGN", "action": "play", "rect": pygame.Rect(sw // 2 - 160, 490, 320, 52)},
            {"label": "QUIT", "action": "quit", "rect": pygame.Rect(sw // 2 - 160, 566, 320, 52)},
        ]
        self.hovered = None

    def handle(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = None
            for b in self.buttons:
                if b["rect"].collidepoint(event.pos): self.hovered = b["action"]
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                if b["rect"].collidepoint(event.pos): return b["action"]
        return None

    def draw(self):
        s = self.surf
        s.fill(cBg)
        for y in range(0, sh, 4): pygame.draw.line(s, (0, 0, 0), (0, y), (sw, y), 1)
        
        t = self.tick * 0.04
        for i in range(40):
            angle = i * (math.pi * 2 / 40) + t
            px = sw // 2 + int(600 * math.cos(angle))
            py = 300 + int(220 * math.sin(angle))
            alpha = int(128 + 80 * math.sin(angle * 3 + t))
            col = (alpha // 3, alpha // 4, 0)
            if 0 <= px < sw and 0 <= py < sh: pygame.draw.rect(s, col, (px, py, 3, 3))
                
        drawText(s, "KRIEGSMINISTER", fontTitle, cGold, sw // 2, 120, shadow=True, center=True)
        drawText(s, "War Minister", fontLg, cParchment, sw // 2, 214, center=True)
        drawText(s, "1914 - 1918", fontMd, cGrey, sw // 2, 262, center=True)
        pygame.draw.line(s, cGold, (sw // 2 - 300, 305), (sw // 2 + 300, 305), 2)
        pygame.draw.line(s, cGold, (sw // 2 - 300, 309), (sw // 2 + 300, 309), 1)
        drawText(s, "Eight turns. Ten technologies. Shape the Great War.", fontSm, cGrey, sw // 2, 330, center=True)
        drawText(s, "Success gives you more resources. Failure takes them away.", fontTiny, cGrey, sw // 2, 358, center=True)
        drawText(s, "Early turns: fewer choices. Endgame unlocks the full arsenal.", fontTiny, cGrey, sw // 2, 378, center=True)
        drawText(s, "Focus. Spreading thin is its own punishment.", fontTiny, cRed, sw // 2, 398, center=True)
        
        for b in self.buttons:
            hover = self.hovered == b["action"]
            bg = cHighlight if hover else cDark
            border = cGold if hover else cGrey
            drawRectBorder(s, b["rect"], border, thickness=2, inner=bg)
            drawText(s, b["label"], fontMd, cWhite if hover else cParchment, b["rect"].centerx, b["rect"].centery - 10, center=True)


KEY_REPEAT_DELAY = 20
KEY_REPEAT_RATE = 1.5


class InvestScreen(Screen):
    cols = 5
    cardW = 220
    cardH = 200
    pad = 10

    def __init__(self, gs, surf):
        super().__init__(gs, surf)
        self.selected = None
        self.hovered = None
        self.cards = self._buildCards()
        self.flash = {}
        self.confirmHover = False
        self.reviewHover = False
        self._keyHeld = {}

    def _buildCards(self):
        cards = []
        totalW = self.cols * self.cardW + (self.cols - 1) * self.pad
        startX = (sw - totalW) // 2
        for i, tech in enumerate(techs):
            col = i % self.cols
            row = i // self.cols
            x = startX + col * (self.cardW + self.pad)
            y = 115 + row * (self.cardH + self.pad)
            cards.append({"tech": tech, "rect": pygame.Rect(x, y, self.cardW, self.cardH)})
        return cards

    def _reviewRect(self): return pygame.Rect(sw // 2 + 170, sh - 62, 220, 48)

    def _confirmRect(self): return pygame.Rect(sw // 2 - 160, sh - 62, 320, 48)

    def _isUnlocked(self, tid): return tid in availableTechs(self.gs.turnIndex)

    def _invest(self, tid, amount):
        if not self._isUnlocked(tid): return
        gs = self.gs
        if amount > 0:
            if gs.yearAlloc[tid] % 2 == 1: gs.yearAlloc[tid] += 1
            can_add = min(amount, gs.pointsLeft)
            gs.yearAlloc[tid] += can_add
            gs.pointsLeft -= can_add
        else:
            can_remove = min(-amount, gs.yearAlloc[tid])
            gs.yearAlloc[tid] -= can_remove
            gs.pointsLeft += can_remove

    def handle(self, event):
        gs = self.gs

        if gs.reviewMode:
            if event.type == pygame.MOUSEMOTION: self.confirmHover = self._confirmRect().collidepoint(event.pos)
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self._confirmRect().collidepoint(event.pos): return "commit"
                back = pygame.Rect(sw // 2 - 400, sh - 62, 220, 48)
                if back.collidepoint(event.pos): gs.reviewMode = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: gs.reviewMode = False
            return None

        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.reviewHover = self.confirmHover = None
            for c in self.cards:
                if c["rect"].collidepoint(event.pos): self.hovered = c["tech"]["id"]
            if self._reviewRect().collidepoint(event.pos): self.reviewHover = True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for c in self.cards:
                if c["rect"].collidepoint(event.pos) and self._isUnlocked(c["tech"]["id"]): self.selected = c["tech"]["id"]
            if self._reviewRect().collidepoint(event.pos) and gs.pointsLeft == 0: gs.reviewMode = True

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RIGHT, pygame.K_UP, pygame.K_LEFT, pygame.K_DOWN):
                self._keyHeld[event.key] = 0
                if self.selected: self._invest(self.selected, 2 if event.key in (pygame.K_RIGHT, pygame.K_UP) else -2)

        if event.type == pygame.KEYUP: self._keyHeld.pop(event.key, None)
        if event.type == pygame.MOUSEWHEEL and self.selected: self._invest(self.selected, 4 if event.y > 0 else -4)
        return None

    def update(self):
        super().update()
        for tid in list(self.flash):
            self.flash[tid] -= 1
            if self.flash[tid] <= 0: del self.flash[tid]
        if self.selected and not self.gs.reviewMode:
            for key, held in list(self._keyHeld.items()):
                self._keyHeld[key] += 1
                ticks = self._keyHeld[key]
                if ticks >= KEY_REPEAT_DELAY and (ticks - KEY_REPEAT_DELAY) % KEY_REPEAT_RATE == 0:
                    self._invest(self.selected, 4 if key in (pygame.K_RIGHT, pygame.K_UP) else -4)

    def draw(self):
        self.surf.fill(cBg)
        if self.gs.reviewMode:
            self._drawReview()
            return
        self._drawHeader()
        for c in self.cards: self._drawCard(self.surf, c, self.gs)
        self._drawFooter()

    def _drawHeader(self):
        s = self.surf
        gs = self.gs
        pygame.draw.rect(s, cDark, (0, 0, sw, 108))
        pygame.draw.line(s, cGold, (0, 108), (sw, 108), 2)
        drawText(s, gs.currentTurn.upper(), fontLg, cGold, sw // 2, 8, center=True)
        scol = cGreen if gs.warScore >= 70 else (cRed if gs.warScore <= 35 else cParchment)
        drawText(s, f"WAR SITUATION: {gs.warScore}/100", fontMd, scol, 24, 12)
        pool = gs.dynamicResourcePool()
        poolCol = cGreen if pool >= resourcePoolBase else cRed
        drawText(s, f"RESOURCES: {gs.pointsLeft} / {pool}", fontMd, poolCol, sw - 300, 12)
        drawText(s, f"{gs.turnIndex+1} OF {len(turns)}", fontSm, cGrey, sw // 2, 55, center=True)
        drawText(s, "Select card · Scroll or Arrow keys to invest · Spend all points.", fontMd, cGrey, sw // 2, 82, center=True)

    def _drawFooter(self):
        s = self.surf
        gs = self.gs
        ready = gs.pointsLeft == 0
        rev = self._reviewRect()
        bg = cHighlight if (ready and self.reviewHover) else cDark
        bdr = cGold if ready else cGrey
        drawRectBorder(s, rev, bdr, 2, bg)
        drawText(s, "REVIEW", fontSm, cWhite if ready else cGrey, rev.centerx, rev.centery - 9, center=True)
        if not ready: drawText(s, f"{gs.pointsLeft} points left to allocate.", fontSm, cRed, sw // 2, sh - 48, center=True)

    def _drawCard(self, s, c, gs):
        tech = c["tech"]
        tid = tech["id"]
        rect = c["rect"]
        unlocked = self._isUnlocked(tid)
        alloc = gs.yearAlloc[tid]
        cum = gs.investments[tid]
        isSel = (self.selected == tid) and unlocked
        isHov = (self.hovered == tid) and unlocked

        if not unlocked:
            pygame.draw.rect(s, cLocked, rect)
            pygame.draw.rect(s, (55, 44, 28), rect, 1)
            drawTechIcon(s, tid, rect.centerx, rect.y + 26, size=28, color=tuple(v // 4 for v in tech["icon_color"]))
            drawText(s, tech["name"], pixelFont(25), (60, 50, 30), rect.centerx, rect.y + 50, center=True, shadow=False)
            bann = pygame.Surface((rect.w - 4, 28), pygame.SRCALPHA)
            bann.fill((10, 6, 2, 200))
            s.blit(bann, (rect.x + 2, rect.centery - 14))
            drawText(s, "LOCKED", fontSm, (100, 70, 30), rect.centerx, rect.centery - 10, center=True, shadow=False)
            ut = tech.get("unlock_turn", 0)
            uname = turns[ut] if ut < len(turns) else "?"
            drawText(s, f"from {uname}", fontTiny, (70, 58, 40), rect.centerx, rect.centery + 18, center=True, shadow=False)
            return

        bg = lerpColor(cDark, tech["icon_color"], 0.15) if isSel else (lerpColor(cDark, cHighlight, 0.06) if isHov else cDark)
        borderC = cGold if isSel else (cHighlight if isHov else cGrey)
        thickness = 3 if isSel else 1
        pygame.draw.rect(s, bg, rect)
        pygame.draw.rect(s, borderC, rect, thickness)

        if tid in self.flash:
            fl = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
            fl.fill((*cGold, 55))
            s.blit(fl, rect.topleft)

        drawTechIcon(s, tid, rect.centerx, rect.y + 26, size=28, color=tech["icon_color"])
        drawText(s, tech["name"], pixelFont(25), tech["icon_color"], rect.centerx, rect.y + 50, center=True)
        drawTextWrapped(s, tech["desc"], pixelFont(20), cGrey, pygame.Rect(rect.x + 6, rect.y + 72, rect.w - 12, 36))

        merged = dict(gs.investments)
        merged[tid] += alloc
        tl = tierLabel(merged, tid)
        drawText(s, tl, fontTiny, tech["icon_color"], rect.centerx, rect.y + 110, center=True)

        maxPts = resourcePoolBase * len(turns)
        bx, by, bw, bh = rect.x + 8, rect.y + 124, rect.w - 16, 8
        pygame.draw.rect(s, cShadow, (bx, by, bw, bh))
        fwCum = int(bw * min(cum, maxPts) / maxPts)
        fwYr = int(bw * min(cum + alloc, maxPts) / maxPts)
        if fwCum > 0: pygame.draw.rect(s, tuple(v // 2 for v in tech["icon_color"]), (bx, by, fwCum, bh))
        if fwYr > fwCum: pygame.draw.rect(s, tech["icon_color"], (bx, by, fwYr, bh))
        pygame.draw.rect(s, cGrey, (bx, by, bw, bh), 1)
        drawText(s, f"This time: {alloc}  Total: {cum+alloc}", fontTiny, cWhite, rect.centerx, by + 10, center=True)

        if isSel:
            y = rect.y + 158
            pro = tech["pros"][0] if tech["pros"] else ""
            con = tech["cons"][0] if tech["cons"] else ""
            drawText(s, f"+ {pro[:28]}", fontTiny, cGreen, rect.x + 4, y)
            drawText(s, f"- {con[:28]}", fontTiny, cRed, rect.x + 4, y + 14)

    def _drawReview(self):
        s = self.surf
        gs = self.gs
        s.fill(cBg)
        panel = pygame.Rect(60, 30, sw - 120, sh - 70)
        pygame.draw.rect(s, cCream, panel)
        pygame.draw.rect(s, cDark, panel, 3)
        pygame.draw.rect(s, cDark, (60, 30, sw - 120, 60))
        drawText(s, f"ALLOCATION REVIEW  —  {gs.currentTurn.upper()}", fontMd, cGold, sw // 2, 42, center=True)
        sc = gs.warScore
        scol = cGreen if sc >= 70 else (cRed if sc <= 35 else (60, 60, 40))
        drawText(s, f"Current war situation: {sc} / 100", fontSm, scol, sw // 2, 100, shadow=False, center=True)
        pool = gs.dynamicResourcePool()
        pcol = (20, 100, 20) if pool >= resourcePoolBase else (120, 20, 20)
        poolNote = "War is going well" if pool >= resourcePoolBase else "War is going badly"
        drawText(s, f"Points this turn: {pool}  ({poolNote})", fontSm, pcol, sw // 2, 126, shadow=False, center=True)
        colHeaders = ["TECHNOLOGY", "THIS TIME", "TOTAL", "LEVEL"]
        colX = [80, 440, 580, 740]
        yHdr = 162
        pygame.draw.line(s, cDark, (80, yHdr + 22), (sw - 80, yHdr + 22), 1)
        for i, hdr in enumerate(colHeaders): drawText(s, hdr, fontSm, cDark, colX[i], yHdr, shadow=False)
        yRow = yHdr + 32
        for idx, tech in enumerate(techs):
            tid = tech["id"]
            alloc = gs.yearAlloc[tid]
            cum = gs.investments[tid]
            merged = dict(gs.investments)
            merged[tid] += alloc
            tl = tierLabel(merged, tid)
            locked = not self._isUnlocked(tid)
            rowC = (60, 50, 30) if locked else ((30, 20, 10) if alloc > 0 else cGrey)
            if idx % 2 == 0: pygame.draw.rect(s, (215, 200, 160), (80, yRow - 2, sw - 160, 22))
            drawText(s, tech["name"], fontSm, rowC, colX[0], yRow, shadow=False)
            drawText(s, f"{alloc:3d} Pts", fontSm, (20, 120, 20) if alloc > 0 else cGrey, colX[1], yRow, shadow=False)
            drawText(s, f"{cum+alloc:3d} Pts", fontSm, rowC, colX[2], yRow, shadow=False)
            tlDisplay = "LOCKED" if locked else tl
            drawText(s, tlDisplay, fontSm, (60, 50, 30) if locked else tech["icon_color"], colX[3], yRow, shadow=False)
            maxPts = resourcePoolBase * len(turns)
            bx, by, bw, bh = 950, yRow + 2, 270, 12
            pygame.draw.rect(s, (180, 165, 130), (bx, by, bw, bh))
            if not locked:
                fw = int(bw * min(cum + alloc, maxPts) / maxPts)
                if fw > 0: pygame.draw.rect(s, tech["icon_color"], (bx, by, fw, bh))
            pygame.draw.rect(s, cDark, (bx, by, bw, bh), 1)
            yRow += 26

        pygame.draw.line(s, cDark, (80, yRow + 4), (sw - 80, yRow + 4), 1)
        drawStamp(s, "GENEHMIGT", sw // 2 + 280, sh // 2, cStampGrn, angleDeg=-14)
        drawText(s, "(Approved)", fontSm, cStampGrn, sw // 2 + 180, sh // 2 + 30, shadow=False, center=True)
        confBtn = self._confirmRect()
        backBtn = pygame.Rect(sw // 2 - 400, sh - 62, 220, 48)
        confCol = cStampGrn if self.confirmHover else cDark
        drawRectBorder(s, confBtn, cStampGrn, 3, confCol)
        drawText(s, "CONFIRM", fontMd, cWhite if self.confirmHover else cParchment, confBtn.centerx, confBtn.centery - 12, center=True)
        drawRectBorder(s, backBtn, cGrey, 2, cDark)
        drawText(s, "BACK TO EDITING", fontSm, cParchment, backBtn.centerx, backBtn.centery - 9, center=True)


TYPEWRITER_SPEED = 2
SENTENCE_PAUSE_TICKS = 38


class EventScreen(Screen):
    def __init__(self, gs, surf):
        super().__init__(gs, surf)
        self.currentIdx = 0
        self.btnHover = False
        self.events = list(gs.eventQueue)

        if not self.events:
            self.events = [{
                "headline": "FRONTBERICHT",
                "english": "Nothing Changed",
                "body": "The season passes without anything new. The front is exactly where it was at the beginning. Nothing that money was spent on has changed a single battle. Somewhere in the building, a general mutters about wasted time.",
                "delta": 0,
                "actual_delta": 0,
            }]
        else:
            for ev in self.events:
                if "actual_delta" not in ev: ev["actual_delta"] = ev.get("delta", 0)

        self._typeChars = 0.0
        self._pauseTimer = 0
        self._typeComplete = False

    def _bodyText(self):
        if self.currentIdx < len(self.events): return self.events[self.currentIdx].get("body", "")
        return ""

    def _bodyLen(self): return len(self._bodyText())

    def _startTypewriter(self):
        self._typeChars = 0.0
        self._pauseTimer = 0
        self._typeComplete = False

    def _skipToEnd(self):
        self._typeChars = float(self._bodyLen())
        self._pauseTimer = 0
        self._typeComplete = True

    def handle(self, event):
        if event.type == pygame.MOUSEMOTION: self.btnHover = self._btnRect().collidepoint(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self._btnRect().collidepoint(event.pos):
                if not self._typeComplete: self._skipToEnd()
                else: return self._advance()
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_SPACE, pygame.K_RETURN):
            if not self._typeComplete: self._skipToEnd()
            else: return self._advance()
        return None

    def _advance(self):
        self.currentIdx += 1
        self._startTypewriter()
        if self.currentIdx >= len(self.events):
            if self.gs.turnIndex >= len(turns) or self.gs.earlyEnd: return "outcome"
            return "invest"
        return None

    def _btnRect(self): return pygame.Rect(sw // 2 - 140, sh - 200, 280, 48)

    def update(self):
        super().update()
        if self._typeComplete: return

        body = self._bodyText()
        total = len(body)

        if self._pauseTimer > 0:
            self._pauseTimer -= 1
            return

        self._typeChars += TYPEWRITER_SPEED

        prev_int = int(self._typeChars - TYPEWRITER_SPEED)
        curr_int = int(self._typeChars)
        for ci in range(max(prev_int, 0), min(curr_int, total)):
            ch = body[ci]
            if ch in ".!?":
                self._typeChars = float(ci + 1)
                self._pauseTimer = SENTENCE_PAUSE_TICKS
                break

        if self._typeChars >= total:
            self._typeChars = float(total)
            self._typeComplete = True

    def draw(self):
        s = self.surf
        gs = self.gs
        s.fill(cBg)
        if self.currentIdx >= len(self.events): return

        ev = self.events[self.currentIdx]
        delta = ev.get("actual_delta", ev.get("delta", 0))

        panel = pygame.Rect(50, 20, sw - 100, sh - 200)
        pygame.draw.rect(s, cCream, panel)
        pygame.draw.rect(s, cDark, panel, 3)
        pygame.draw.rect(s, cDark, (50, 20, sw - 100, 54))

        turnName = turns[max(0, gs.turnIndex - 1)]
        phase = turnPhases.get(turnName, "")
        drawText(s, f"DEPESCHE  —  {turnName.upper()}  —  {phase}", fontMd, cGold, sw // 2, 30, center=True)
        drawText(s, f"Report {self.currentIdx+1} of {len(self.events)}", fontTiny, cGrey, sw - 200, 30, shadow=False)

        drawText(s, ev["headline"], fontLg, (30, 20, 10), sw // 2, 82, shadow=False, center=True)
        if ev.get("english"): drawText(s, ev["english"], fontSm, cGrey, sw // 2, 118, shadow=False, center=True)
        pygame.draw.line(s, cDark, (100, 146), (sw - 100, 146), 1)

        bodyRect = pygame.Rect(100, 160, sw - 200, 370)
        charsVis = int(self._typeChars)
        drawTextWrappedPartial(s, ev["body"], fontMd, (30, 20, 10), bodyRect, lineSpacing=10, charsVisible=None if self._typeComplete else charsVis)

        if not self._typeComplete and self._pauseTimer == 0 and (self.tick // 20) % 2 == 0:
            lines = wrapText(ev["body"], fontMd, bodyRect.width)
            cy, shown = bodyRect.y, 0
            for line in lines:
                if shown + len(line) >= charsVis:
                    partial = line[: charsVis - shown]
                    cx = bodyRect.x + fontMd.size(partial)[0] + 2
                    pygame.draw.rect(s, (30, 20, 10), (cx, cy, 3, fontMd.get_height()))
                    break
                shown += len(line)
                cy += fontMd.get_height() + 10

        if delta != 0 and self._typeComplete:
            stampText = f"+{delta}" if delta > 0 else str(delta)
            stampCol = cStampGrn if delta > 0 else cStampRed
            drawStamp(s, stampText, sw - 160, 240, stampCol, angleDeg=-10)
            verb = "VORTEILHAFT" if delta > 0 else "NACHTEILIG"
            verbEng = "(Advantage)" if delta > 0 else "(Disadvantage)"
            drawStamp(s, verb, sw - 160, 308, stampCol, angleDeg=-10, font=fontSm)
            drawText(s, verbEng, fontTiny, stampCol, sw - 160, 345, shadow=False, center=True)

        pygame.draw.line(s, cDark, (100, sh - 118), (sw - 100, sh - 118), 1)
        barY = sh - 110
        drawText(s, f"War Situation:  {gs.warScore} / 100", fontSm, (60, 50, 40), sw // 2, barY, shadow=False, center=True)
        bx, by, bw, bh = 100, barY + 28, sw - 200, 18
        pygame.draw.rect(s, (150, 135, 110), (bx, by, bw, bh))
        fw = int(bw * gs.warScore / 100)
        bc = (20, 120, 20) if gs.warScore >= 70 else ((140, 20, 20) if gs.warScore <= 35 else (160, 120, 20))
        if fw > 0: pygame.draw.rect(s, bc, (bx, by, fw, bh))
        pygame.draw.line(s, (180, 30, 20), (bx + int(bw * 0.35), by - 2), (bx + int(bw * 0.35), by + bh + 2), 2)
        pygame.draw.line(s, (20, 140, 20), (bx + int(bw * 0.70), by - 2), (bx + int(bw * 0.70), by + bh + 2), 2)
        pygame.draw.rect(s, cDark, (bx, by, bw, bh), 2)

        if self.currentIdx == len(self.events) - 1 and gs.turnIndex < len(turns) and not gs.earlyEnd:
            nextPool = gs.dynamicResourcePool()
            pcol = (20, 100, 20) if nextPool >= resourcePoolBase else (140, 20, 20)
            drawText(s, f"Next turn: {nextPool} points available.", fontSm, pcol, sw // 2, by + bh + 8, shadow=False, center=True)

        if self.currentIdx == len(self.events) - 1 and not gs.earlyEnd:
            nextIdx = gs.turnIndex
            if nextIdx < len(turns):
                curUnlocked = availableTechs(nextIdx)
                prevUnlocked = availableTechs(max(0, nextIdx - 1))
                newOnes = curUnlocked - prevUnlocked
                if newOnes:
                    names = ", ".join(techById[tid]["name"] for tid in newOnes if tid in techById)
                    drawText(s, f"Newly unlocked: {names}", fontSm, cGold, sw // 2, by + bh + 32, shadow=False, center=True)

        btn = self._btnRect()
        isLast = self.currentIdx == len(self.events) - 1
        if not self._typeComplete: label = "SKIP"
        elif isLast: label = "VIEW RESULT" if (gs.turnIndex >= len(turns) or gs.earlyEnd) else "NEXT TURN"
        else: label = "NEXT REPORT"
        drawRectBorder(s, btn, cDark, 2, cDark)
        drawText(s, label, fontSm, cGold if self.btnHover else cParchment, btn.centerx, btn.centery - 9, center=True)
        drawText(s, "SPACE or ENTER", fontTiny, cGrey, btn.centerx, btn.bottom + 4, shadow=False, center=True)


class OutcomeScreen(Screen):
    def __init__(self, gs, surf):
        super().__init__(gs, surf)
        self.result = gs.result()
        self.out = outcomes[self.result]
        self.btnHover = False

    def _btnRect(self): return pygame.Rect(sw // 2 - 160, sh - 72, 320, 52)

    def handle(self, event):
        if event.type == pygame.MOUSEMOTION: self.btnHover = self._btnRect().collidepoint(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self._btnRect().collidepoint(event.pos): return "menu"
        return None

    def draw(self):
        s = self.surf
        gs = self.gs
        out = self.out
        col = out["color"]
        s.fill(cBg)

        alpha = int(80 + 60 * math.sin(self.tick * 0.03))
        bs = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.rect(bs, (*col, alpha), (0, 0, sw, sh), 24)
        s.blit(bs, (0, 0))

        panel = pygame.Rect(50, 20, sw - 100, sh - 90)
        pygame.draw.rect(s, cCream, panel)
        pygame.draw.rect(s, cDark, panel, 3)
        pygame.draw.rect(s, cDark, (50, 20, sw - 100, 54))

        drawText(s, "FINAL EVALUATION — 1914 TO 1918", fontMd, cGold, sw // 2, 30, center=True)
        drawText(s, out["title"], fontXl, col, sw // 2, 84, shadow=False, center=True)
        drawText(s, out["english"], fontSm, cGrey, sw // 2, 152, shadow=False, center=True)
        drawText(s, out["subtitle"], fontMd, (60, 50, 30), sw // 2, 176, shadow=False, center=True)
        pygame.draw.line(s, cDark, (100, 212), (sw - 100, 212), 1)

        bodyR = pygame.Rect(100, 222, sw - 200, 210)
        drawTextWrapped(s, out["body"], fontSm, (30, 20, 10), bodyR, lineSpacing=8)
        pygame.draw.line(s, cDark, (100, 445), (sw - 100, 445), 1)
        drawText(s, "Where the money went:", fontSm, (30, 20, 10), 100, 452, shadow=False)
        
        xo = 100
        for tech in techs:
            tid = tech["id"]
            total = gs.investments[tid]
            if total > 0:
                tl = tierLabel(gs.investments, tid)
                drawText(s, f"{tech['name'][:12]}: {total} ({tl[:10]})", fontTiny, tech["icon_color"], xo, 478, shadow=False)
                xo += 210
                if xo > sw - 230: xo = 100

        if gs.flags:
            drawText(s, "What happened:", fontSm, (30, 20, 10), 100, 502, shadow=False)
            fx = 100
            for flag in sorted(gs.flags):
                drawText(s, flag.replace("_", " "), fontTiny, cGrey, fx, 524, shadow=False)
                fx += 190
                if fx > sw - 220: fx = 100

        scoreBarY = sh - 78
        drawText(s, f"Final Score: {gs.warScore} / 100", fontSm, cDark, sw // 2, scoreBarY - 26, shadow=False, center=True)
        bx, by, bw, bh = 100, scoreBarY, sw - 200, 22
        pygame.draw.rect(s, (150, 135, 110), (bx, by, bw, bh))
        fw = int(bw * gs.warScore / 100)
        bc = (20, 120, 20) if gs.warScore >= 70 else ((140, 20, 20) if gs.warScore <= 35 else (160, 120, 20))
        if fw > 0: pygame.draw.rect(s, bc, (bx, by, fw, bh))
        pygame.draw.line(s, (180, 30, 20), (bx + int(bw * 0.35), by - 2), (bx + int(bw * 0.35), by + bh + 2), 2)
        pygame.draw.line(s, (20, 140, 20), (bx + int(bw * 0.70), by - 2), (bx + int(bw * 0.70), by + bh + 2), 2)
        pygame.draw.rect(s, cDark, (bx, by, bw, bh), 2)
        drawText(s, "Defeat", fontTiny, (180, 30, 20), bx, by + bh + 3, shadow=False)
        drawText(s, "Stalemate", fontTiny, (160, 120, 20), bx + int(bw * 0.35) + 4, by + bh + 3, shadow=False)
        drawText(s, "Victory", fontTiny, (20, 140, 20), bx + int(bw * 0.70) + 4, by + bh + 3, shadow=False)

        drawStamp(s, out["stamp"], sw - 170, 320, col, angleDeg=-15)
        drawText(s, out["stamp_english"], fontSm, col, sw - 170, 368, shadow=False, center=True)

        if gs.earlyEnd: drawText(s, "The war ended prematurely. The situation was beyond saving.", fontSm, cRed, sw // 2, 560, shadow=False, center=True)

        btn = self._btnRect()
        bg = cGold if self.btnHover else cDark
        tc = (30, 20, 10) if self.btnHover else cParchment
        drawRectBorder(s, btn, col, 2, bg)
        drawText(s, "RETURN TO MAIN MENU", fontSm, tc, btn.centerx, btn.centery - 10, center=True)


async def main():
    screen = pygame.display.set_mode((sw, sh))
    pygame.display.set_caption("Kriegsminister 1914-1918")
    clock = pygame.time.Clock()
    gs = GameState()
    currentScreen = MenuScreen(gs, screen)

    def transition(action):
        nonlocal currentScreen, gs
        if action == "play":
            gs.reset()
            gs.startTurn()
            gs.phase = "invest"
            currentScreen = InvestScreen(gs, screen)
        elif action == "commit":
            nextPhase = gs.commitYear()
            gs.phase = nextPhase
            currentScreen = (
                EventScreen(gs, screen)
                if nextPhase == "event"
                else OutcomeScreen(gs, screen)
            )
        elif action == "invest":
            gs.phase = "invest"
            currentScreen = InvestScreen(gs, screen)
        elif action == "outcome":
            gs.phase = "outcome"
            currentScreen = OutcomeScreen(gs, screen)
        elif action == "menu":
            gs.phase = "menu"
            currentScreen = MenuScreen(gs, screen)
        elif action == "quit":
            pygame.quit()
            return "break_loop"

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            result = currentScreen.handle(event)
            if result:
                action_outcome = transition(result)
                if action_outcome == "break_loop":
                    running = False
                    break
                

                currentScreen.update()
                currentScreen.draw()
                pygame.display.flip()

        if not running:
            break

        currentScreen.update()
        currentScreen.draw()
        pygame.display.flip()
        
        await asyncio.sleep(0)
        clock.tick(fps)

asyncio.run(main())